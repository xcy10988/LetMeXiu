<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "yemaijiu";
	
	
	$yonghumingzi = $_GET['yhm'];
	$yonghumima = $_GET['yhmm'];
    
	$conn = new mysqli($servername, $username, $password, $dbname);
	
	//查询前设置编码，防止输出乱码
    $conn->set_charset('utf8');
    	
	//编写sql语句
	$sqlqwe =  'select  count(*) from yonghubiao where usname = "'.$yonghumingzi.'" ';
	$result = $conn->query($sqlqwe);	
    //使用查询结果集
    //得到数组
    $row = $result->fetch_all(MYSQLI_ASSOC);  	
    //把结果输出到前端
    //判断数据库是否已有相同的数据
    $abc = json_encode($row,JSON_UNESCAPED_UNICODE);  //[{"count(*)":"0"}]
    if($abc[14] == 0){
    	$sql = 'insert into yonghubiao (usname,password) values("'.$yonghumingzi.'","'.$yonghumima.'")';
	    $conn->query($sql);
	    if($conn->query($sql)){
	    	echo"成功注册,请登录";
	    }else{
	    	echo"失败";
	    }
    }else{
    	echo"该用户名已存在,请重新注册";
    }
//  echo $yhm,$mm;
    //释放查询结果集，避免资源浪费
    $result->close();

//	if( $abc == 0){
//		echo "可以";
//	}else{
//		echo "不可以";
//	}
	
 
    //关闭数据库，避免资源浪费
    $conn->close(); 
?>