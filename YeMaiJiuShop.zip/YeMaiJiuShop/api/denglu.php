<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "yemaijiu";

$yhm = $_GET['yhm'];
$mm = $_GET['yhmm'];

$conn = new mysqli($servername, $username, $password, $dbname);

//查询前设置编码，防止输出乱码
$conn->set_charset('utf8');

//编写sql语句
$sql = 'select * from yonghubiao where usname = "' . $yhm . '" ';

//获取查询结果集
$result = $conn->query($sql);

//使用查询结果集
//得到数组
$row = $result->fetch_all(MYSQLI_ASSOC);

//把结果输出到前端
echo json_encode($row, JSON_UNESCAPED_UNICODE);
//  echo $yhm,$mm;
//释放查询结果集，避免资源浪费
$result->close();

//	var_dump($row);
//关闭数据库，避免资源浪费
$conn->close();
?>
