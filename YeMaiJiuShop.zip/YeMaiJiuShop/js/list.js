jQuery(function($) {
	$('.headxcy').load('../index.html #tophead', function() {
		$('#neirong').hide();
		$('.one').css('background', '#624B40');
		$('.one').mousemove(function() {
			$('#neirong').show();
		}).mouseleave(function() {
			$('#neirong').hide();
		});
		$('#bt').css('margin-top', '-1px');
	});
	$('.footxcy').load('../index.html #qw');

});
