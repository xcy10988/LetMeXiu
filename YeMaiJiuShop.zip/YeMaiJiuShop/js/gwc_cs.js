$(function() {
	var canshu = decodeURI(location.search).slice(1); //去掉问号

	var shuju = canshu.split("&");
	// 	console.log(canshu.split(':'));
	// 	console.log(shuju);
	var obj2 = {};
	shuju.forEach(function(i) {
		var aa = i.split("=");
		obj2[aa[0]] = aa[1];
	})

	if (obj2.tp == undefined) {
		alert("您还没有选择商品!");
		nyd();
	} else {
		var str666;
		str666 =
			'<ul class="order_lists"><li class="list_chk"><input type="checkbox" id="checkbox_2" class="son_check"><label for="checkbox_2"></label></li><li class="list_con"><div class="list_img"><a href="javascript:;"><img src="../' +
			obj2.tp + '" alt="" height="100px"></a></div><div class="list_text"><a href="javascript:;">' + obj2.name +
			'</a></div></li><li class="list_info"><p>' + obj2.xiangqing + '</p><p>' + obj2.xiangqing +
			'</p></li><li class="list_price"><p class="price">￥' + obj2.jiage +
			'</p></li><li class="list_amount"> <div class="amount_box"><a href="javascript:;" class="reduce reSty">-</a><input type="text" value="1" class="sum"> <a href="javascript:;" class="plus">+</a></div></li><li class="list_sum"><p class="sum_price">￥' +
			obj2.jiage +
			'</p> </li><li class="list_op"><p class="del"><a href="javascript:;" class="delBtn">移除商品</a></p></li></ul>';


		var ddd = $('.order_content')[0];
		ddd.innerHTML = str666;
		$.getScript("../js/gwcjs.js", function() { //加载test.js,成功后，并执行回调函数
		});
		nyd();
	};

	function nyd() {
		var ddd = $('.order_content')[0];
		//下面快捷点击加入购物车
		var num = 2;
		var kj = $('.jrgwc');
		kj.click(function() {
			num++;
			var tpp = $(this).parent().parent()[0];
			var nydtp = $(tpp).find("img")[0];
			var nydtp2 = nydtp.src;

			var jgg = $(this).parent().parent()[0];
			var nydjg = $(tpp).find("strong")[0].innerHTML;

			var mzz = $(this).parent().parent()[0];
			var nydmz = $(tpp).find("p")[0].innerHTML;


			var xqq = $(this).parent().parent()[0];
			var nydxq = $(tpp).find("p")[1].innerHTML;

			str666 += '<ul class="order_lists"><li class="list_chk"><input type="checkbox" id="checkbox_' + num +
				'" class="son_check"><label for="checkbox_' + num +
				'"></label></li><li class="list_con"><div class="list_img"><a href="javascript:;"><img src="' + nydtp2 +
				'" alt="" height="100px"></a></div><div class="list_text"><a href="javascript:;">' + nydmz +
				'</a></div></li><li class="list_info"><p>' + nydxq + '</p><p>' + nydxq +
				'</p></li><li class="list_price"><p class="price">' + nydjg +
				'</p></li><li class="list_amount"> <div class="amount_box"><a href="javascript:;" class="reduce reSty">-</a><input type="text" value="1" class="sum"> <a href="javascript:;" class="plus">+</a></div></li><li class="list_sum"><p class="sum_price">' +
				nydjg +
				'</p> </li><li class="list_op"><p class="del"><a href="javascript:;" class="delBtn">移除商品</a></p></li></ul>';
			ddd.innerHTML = str666;

			//重新调用这个js注册各种事件
			$.getScript("../js/gwcjs.js", function() { //加载test.js,成功后，并执行回调函数
			});

		})
	}

})
