jQuery(function($) {
	/*
		$box.load(url,callback)：把url文件内容写入$box
			* ajax请求
			* 异步请求
			* 加载部分内容
			* 回掉函数：加载完成后执行
	 */
	$('.headxcy').load('../index.html #tophead', function() {
		$('#neirong').hide();
		$('.one').css('background', '#624B40');
		$('.one').mousemove(function() {
			$('#neirong').show();
		}).mouseleave(function() {
			$('#neirong').hide();
		});


		//设置点击logo返回首页
		var aa = document.getElementById("rgb1")
		aa.href = '../index.html';

		//设置点击查看购物车进入购物车页面
		var aa = document.getElementById("rgb2")
		aa.href = 'car.html';

	});
	$('.footxcy').load('../index.html #qw');



	var pl = $('#pinglun');
	var plk = $('#plk');
	pl.click(function() {
		plk.show();
	});


	$('#hp').click(function() {
		$('#hpq').show();
		$('#hpq').siblings('.kk').hide();
	})

	$('#yb').click(function() {
		$('#ybq').show();
		$('#ybq').siblings('.kk').hide();
	})

	$('#lj').click(function() {
		$('#ljq').show();
		$('#ljq').siblings('.kk').hide();
	})
	var no1 = $('.no1');
	var no2 = $('.no2');
	var no3 = $('.no3');
	$('#plbtn').click(function() {
		var aa = "丶" + $('#hhk').val() + $('#ybk').val() + $('#ljk').val();
		//		console.log();
		if ($("#hp").is(":checked")) {
			$lis = $('<li/>');
			$lis.html(aa).prependTo("#ling");
			no1.addClass('shows');
			no1.siblings().addClass('hidden');
			no1.siblings().removeClass('shows');
		} else if ($("#yb").is(":checked")) {
			$lis = $('<li/>');
			$lis.html(aa).prependTo("#yi");
			no2.addClass('shows');
			no2.siblings().addClass('hidden');
			no2.siblings().removeClass('shows');
		} else if ($("#lj").is(":checked")) {
			$lis = $('<li/>');
			$lis.html(aa).prependTo("#er");
			no3.addClass('shows');
			no3.siblings().addClass('hidden');
			no3.siblings().removeClass('shows');
		} else {
			alert("你干嘛");
		}
	})


	//	console.log(ymgd);
	//	var $ymgd =$(window).height();
	$(document).scroll(function() {
		if (window.scrollY > ($(window).height() * 0.6)) {
			$('#gensui').show();
		} else {
			$('#gensui').hide();
		}
	})



});
