function checkna() {
	na = form1.yourname.value;
	if (na.length < 1 || na.length > 12) {
		divname.innerHTML = '<font class="tips_false">长度是1~12个字符</font>';
	} else {
		divname.innerHTML = '<font class="tips_true">输入正确</font>';
	}
}
//验证密码 
function checkpsd1() {
	psd1 = form1.yourpass.value;
	var flagZM = false;
	var flagSZ = false;
	var flagQT = false;
	if (psd1.length < 6 || psd1.length > 12) {
		divpassword1.innerHTML = '<font class="tips_false">长度错误</font>';
	} else {
		for (i = 0; i < psd1.length; i++) {
			if ((psd1.charAt(i) >= 'A' && psd1.charAt(i) <= 'Z') || (psd1.charAt(i) >= 'a' && psd1.charAt(i) <= 'z')) {
				flagZM = true;
			} else if (psd1.charAt(i) >= '0' && psd1.charAt(i) <= '9') {
				flagSZ = true;
			} else {
				flagQT = true;
			}
		}
		if (!flagZM || !flagSZ || flagQT) {
			divpassword1.innerHTML = '<font class="tips_false">密码必须是字母数字的组合</font>';
		} else {
			divpassword1.innerHTML = '<font class="tips_true">输入正确</font>';
		}
	}
}

//验证确认密码 

function checkpsd2() {

	if (form1.yourpass.value != form1.yourpass2.value) {

		divpassword2.innerHTML = '<font class="tips_false">您两次输入的密码不一样</font>';

	} else {

		divpassword2.innerHTML = '<font class="tips_true">输入正确</font>';

	}

}

//验证邮箱



function checkmail() {

	apos = form1.youremail.value.indexOf("@");

	dotpos = form1.youremail.value.lastIndexOf(".");

	if (apos < 1 || dotpos - apos < 2)

	{

		divmail.innerHTML = '<font class="tips_false">输入错误</font>';

	} else {

		divmail.innerHTML = '<font class="tips_true">输入正确</font>';

	}

}


var phoneReg = /(^1[3|4|5|7|8]\d{9}$)|(^09\d{8}$)/; //手机号正则 
var count = 60; //间隔函数，1秒执行
var InterValObj1; //timer变量，控制时间
var curCount1; //当前剩余秒数
/*第一*/
function sendMessage1() {
	curCount1 = count;
	var phone = $.trim($('#phone1').val());
	if (!phoneReg.test(phone)) {
		alert(" 请输入有效的手机号码");
		return false;
	}
	//设置button效果，开始计时
	$("#btnSendCode1").attr("disabled", "true");
	$("#btnSendCode1").val(+curCount1 + "秒再获取");
	InterValObj1 = window.setInterval(SetRemainTime1, 1000); //启动计时器，1秒执行一次
	//向后台发送处理数据

}

function SetRemainTime1() {
	if (curCount1 == 0) {
		window.clearInterval(InterValObj1); //停止计时器
		$("#btnSendCode1").removeAttr("disabled"); //启用按钮
		$("#btnSendCode1").val("重新发送");
	} else {
		curCount1--;
		$("#btnSendCode1").val(+curCount1 + "秒再获取");
	}
}

/*提交*/
// 			function binding(){
// 				alert();
// 			}
// 

$(function() {
	var show_num = [];
	draw(show_num);

	$("#canvas").on('click', function() {
		draw(show_num);
	})
	$(".btn").on('click', function() {
		var val = $(".input-val").val().toLowerCase();
		var num = show_num.join("");
		if (val == '') {
			var phone = $.trim($('#phone1').val());
			if (!phoneReg.test(phone)) {
				//				alert(" 请输入有效的手机号码");
				return false;
			}
			alert('请输入验证码！');
		} else if (val == num) {
			alert('提交成功！');
			$(".input-val").val('');
			draw(show_num);
			//注册信息提交数据库
			luru();
		} else {
			alert('验证码错误！请重新输入！');
			$(".input-val").val('');
			draw(show_num);
		}
	})
	//注册信息提交数据库的方法
	function luru() {
		var yhm = $('#yhm').val();
		var yhmm = $('#mima').val();
		$.ajax({
			type: "GET",
			url: "../api/zhuce.php",
			data: {
				yhmm: yhmm,
				yhm: yhm
			},
			success: function(res) {
				//				alert("注册成功,请登录");
				alert(res);
				location.href = "login.html";
			}
		});
	}
})

function draw(show_num) {
	var canvas_width = $('#canvas').width();
	var canvas_height = $('#canvas').height();
	var canvas = document.getElementById("canvas"); //获取到canvas的对象，演员
	var context = canvas.getContext("2d"); //获取到canvas画图的环境，演员表演的舞台
	canvas.width = canvas_width;
	canvas.height = canvas_height;
	var sCode = "A,B,C,E,F,G,H,J,K,L,M,N,P,Q,R,S,T,W,X,Y,Z,1,2,3,4,5,6,7,8,9,0";
	var aCode = sCode.split(",");
	var aLength = aCode.length; //获取到数组的长度

	for (var i = 0; i <= 3; i++) {
		var j = Math.floor(Math.random() * aLength); //获取到随机的索引值
		var deg = Math.random() * 30 * Math.PI / 180; //产生0~30之间的随机弧度
		var txt = aCode[j]; //得到随机的一个内容
		show_num[i] = txt.toLowerCase();
		var x = 10 + i * 20; //文字在canvas上的x坐标
		var y = 20 + Math.random() * 8; //文字在canvas上的y坐标
		context.font = "bold 23px 微软雅黑";

		context.translate(x, y);
		context.rotate(deg);

		context.fillStyle = randomColor();
		context.fillText(txt, 0, 0);

		context.rotate(-deg);
		context.translate(-x, -y);
	}
	for (var i = 0; i <= 5; i++) { //验证码上显示线条
		context.strokeStyle = randomColor();
		context.beginPath();
		context.moveTo(Math.random() * canvas_width, Math.random() * canvas_height);
		context.lineTo(Math.random() * canvas_width, Math.random() * canvas_height);
		context.stroke();
	}
	for (var i = 0; i <= 30; i++) { //验证码上显示小点
		context.strokeStyle = randomColor();
		context.beginPath();
		var x = Math.random() * canvas_width;
		var y = Math.random() * canvas_height;
		context.moveTo(x, y);
		context.lineTo(x + 1, y + 1);
		context.stroke();
	}
}

function randomColor() { //得到随机的颜色值
	var r = Math.floor(Math.random() * 256);
	var g = Math.floor(Math.random() * 256);
	var b = Math.floor(Math.random() * 256);
	return "rgb(" + r + "," + g + "," + b + ")";
}
