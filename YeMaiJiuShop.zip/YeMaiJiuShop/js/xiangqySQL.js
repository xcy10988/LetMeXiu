//根据url传来的id去数据库拿数据
var nydcs = window.location.href.slice(-1);
//alert(nydcs);  //得到参数--商品id	
var bbooxx = $('.bbooxx')[0];

function jszy() {
	$.ajax({
		type: "GET",
		url: "../api/goods.php",
		data: {
			jszg: nydcs
		},
		success: function(res) {
			var abd;
			abd = $.parseJSON(res);
			//abd[0].goodname;	//商品名
			//abd[0].id;		//商品id
			//abd[0].jiage   //商品价格
			//abd[0].goodxiangqing;  //商品详情
			//abd[0].tupianlujing;  //图片路径
			//abd[0].shouchu;  //已售出数量		
			var str;
			var str2;
			str = '<p><span class="zuhe" style="margin-right:20px;">组合</span><strong>' + abd[0].goodname +
				'</strong><span class="yingwen"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' +
				abd[0].goodxiangqing + '</span></p><img src="img/nidong.png" ><span class="wz">促销价<span id="jiaqian">￥' + abd[0]
				.jiage +
				'</span></span><div class="huang">配送城市:<select><option value ="深圳" selected="selected">深圳</option><option value ="北京" selected="">北京</option><option value ="广州" selected="">广州</option></select><br>选择数量:<input type="number" name="" id="" value="" /></div>';
			//<button type="button" id="gwbt">加入购物车</button>
			bbooxx.innerHTML = str;

			var cjul = $('.dierge .ceni ul');
			$.each(cjul, function(i, e) {
				str2 = '<li><img src="img/tb1.png"/><span class="huise1">类型</span><span id="lx01">' + abd[0].goodxiangqing +
					'</span></li><li><img src="img/tb3.png"/><span class="huise1">容量</span><span id="lx02">' + abd[0].rongliang +
					'</span></li><li><img src="img/tb3.png"/><span class="huise1">醒酒时间</span><span id="lx03">' + abd[0].id +
					'小时</span></li><li><img src="img/tp2.png"/><span class="huise1">搭配菜肴</span><span id="lx04"> 蜜梨佐姜汁冰淇淋</span></li>';
				e.innerHTML = str2;
			});

			//输入商品信息到购物车页面
			var gwbtn = $('#gwbt');
			gwbtn.click(function() {
				// location.href = "html/goods.html?id=" + nydid;
				location.href = "car.html?tp=" + abd[0].tupianlujing + "&name=" + abd[0].goodname + "&xiangqing=" + abd[0].goodxiangqing +
					"&jiage=" + abd[0].jiage;
			})

		}
	});

}
jszy();
