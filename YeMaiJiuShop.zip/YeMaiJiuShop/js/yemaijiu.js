jQuery(function($) {
	$("a").target = "_blank";

	//top
	var no1 = $('.no1');
	var no2 = $('.no2');
	var no3 = $('.no3');
	$('#cx').mousemove(function() {
		no1.addClass('shows');
		no1.siblings().addClass('hidden');
		no1.siblings().removeClass('shows');
	})
	$('#zx').mousemove(function() {
		no2.addClass('shows');
		no2.siblings().addClass('hidden');
		no2.siblings().removeClass('shows');
	})
	$('#mt').mousemove(function() {
		no3.addClass('shows');
		no3.siblings().addClass('hidden');
		no3.siblings().removeClass('shows');
	})

	var bhli = $('#bh li');
	bhli.mousemove(function() {
		$(this).siblings().removeClass('bred');
		$(this).addClass('bred');
	})


	// center
	var $boxx = $('.boxx');
	$boxx.mousemove(function() {
		// console.log($(this));
		$(this).siblings('.boxx').children('.xiao').show();
		$(this).siblings('.boxx').children('.da').hide();
		$(this).children('.xiao').hide();
		$(this).children('.da').show();
	})


	// 二级菜单	
	var $erji = $('.erji');
	var $lili = $('#neirong ul li');
	$lili.mousemove(function() {
		// console.log("123");
		$(this).children('.erji').stop().show(500);
	}).mouseleave(function() {
		$(this).children('.erji').stop().hide(200);
	})



	//数据库导入数据

	function sjk() {
		$.ajax({
			type: "GET",
			url: "api/yemaijiu.php",
			success: function(res) {
				var abd;
				abd = $.parseJSON(res);
				//			abd[].goodname;	//商品名
				//			abd[].id;		//商品id
				//			abd[].jiage   //商品价格
				//			abd[].goodxiangqing;  //商品详情
				//			abd[].tupianlujing;  //图片路径
				//			abd[].shouchu;  //已售出数量
				var str;
				var str2;
				var d = $(".zhong .jiu");
				$.each(d, function(i, e) {
					str = '<img src="' + abd[i].tupianlujing + '" ><p class="pp"><span class="red"><strong>' + abd[i].goodname +
						'</strong></span><br>&nbsp;&nbsp;' + abd[i].goodxiangqing + '<span class="rr"><i>￥' + abd[i].jiage +
						'</i></span></p><p class="bai">售出' + abd[i].shouchu + '</p>';
					e.innerHTML = str;
					$(e).attr("spid", abd[i].id);
				});

				var a = $(".xiaa .jiu");
				$.each(a, function(i, e) {
					str = '<img src="' + abd[i].tupianlujing + '" ><p class="pp"><span class="red"><strong>' + abd[i].goodname +
						'</strong></span><br>&nbsp;&nbsp;' + abd[i].goodxiangqing + '<span class="rr"><i>￥' + abd[i].jiage +
						'</i></span></p><p class="bai">售出' + abd[i].shouchu + '</p>';
					e.innerHTML = str;
					$(e).attr("spid", abd[i].id);
				});

				var c = $("#roll .jiu");
				$.each(c, function(i, e) {
					$(e).attr("spid", abd[i].id);
				});



				//点击进入详情页面
				var jiuid = $('.jiu');
				jiuid.click(function() {
					var nydid = $(this).attr("spid");
					location.href = "html/goods.html?id=" + nydid;
				})

			}
		});
	}
	sjk();



});
