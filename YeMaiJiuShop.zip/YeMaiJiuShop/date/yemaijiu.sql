/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50714
 Source Host           : localhost:3306
 Source Schema         : yemaijiu

 Target Server Type    : MySQL
 Target Server Version : 50714
 File Encoding         : 65001

 Date: 27/10/2018 10:56:31
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods`  (
  `goodname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `id` int(50) UNSIGNED NOT NULL AUTO_INCREMENT,
  `jiage` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `goodxiangqing` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tupianlujing` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `jieshao` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `shouchu` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `rongliang` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('哥黑比诺红葡萄酒', 1, '128.00', ' 红葡萄酒 ', 'img/jiu1.jpg', 'Mud House Central Otago Pinot Noir', '123', '750ml');
INSERT INTO `goods` VALUES ('克兰朵红葡萄酒', 2, '199.00', '葡萄酒', 'img/jiu2.png', 'Clarendelle Rouge Bordeaux AOC', '456', '600ml');
INSERT INTO `goods` VALUES ('智象精选干红葡萄酒', 3, '49.00', '干红', 'img/jiu3.jpg', 'CHILE PHANT SELECTION RED WINE', '133', '800ml');
INSERT INTO `goods` VALUES ('【名庄】露儿城堡干红', 4, '598.00', 'PT酒', 'img/jiu4.png', 'Chateau Leoville Barton 2013', '101', '1200ml');
INSERT INTO `goods` VALUES ('芙丽诗红葡萄酒', 5, '123.00', '葡丶萄酒', 'img/jiu5.jpg', 'FOLICHONNET', '202', '9999ml');

-- ----------------------------
-- Table structure for yonghubiao
-- ----------------------------
DROP TABLE IF EXISTS `yonghubiao`;
CREATE TABLE `yonghubiao`  (
  `usname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yonghubiao
-- ----------------------------
INSERT INTO `yonghubiao` VALUES ('letmesee', 'qwe7896');
INSERT INTO `yonghubiao` VALUES ('xcy10988', '10988zxc');
INSERT INTO `yonghubiao` VALUES ('123', '123qwe');

SET FOREIGN_KEY_CHECKS = 1;
